Super Mario Brothers 2 Japan FDS Text Editor
Programmed by: Shawn M. Crawford [sleepy]
Last Update: July 3rd, 2017 in C#
Latest Build: 1.0.1
 ----

Features:
	* edit every line of text in the game
	* this version tested with J rom (Super Mario Brothers 2 (Japan).fds), might work with other versions but untested because it relies on offsets in the ROM

Requires:
	* .Net Framework 3.5

Usage:
	*Open the Rom (Super Mario Brothers 2 (Japan).fds), change text, click "Update Text", make sure you have a backup in case something breaks.
	*Feel free to email bugs to sleepy3d@gmail.com

 ----
1.0.1  July 3rd, 2017
-fixed major bug with writing text to the ROM
 ----
1.0  June 27th, 2017
-initial release
 ----